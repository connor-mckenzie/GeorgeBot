import { GuildChannel } from 'discord.js';

const Discord = require('discord.js');

const bot = new Discord.Client();
const PREFIX = "!";
let gameRole = "";
let rulesChannel = member.guild.find("name", "rules");
var fortunes = [
    "As I see it, yes",
    "Ask again later",
    "Better not tell you now",
    "Cannot predict now",
    "Concentrate and ask again",
    "Don’t count on it",
    "It is certain",
    "It is decidedly so",
    "Most likely",
    "My reply is no",
    "My sources say no",
    "Outlook good",
    "Outlook not so good",
    "Reply hazy try again",
    "Signs point to yes",
    "Very doubtful",
    "Without a doubt",
    "Yes",
    "Yes, definitely",
    "You may rely on it",
    "Whomst've cares"
];

bot.on("guildMemberAdd", function(member) {
    member.guild.channels.find("name", "greetings-and-announcements").sendMessage(member + ", welcome to Divine's discord. \n Head over to "+ rulesChannel +" to learn a little bit more about our server and how to get your needed roles.");
});

bot.on('message', function(message) {
    
    if (message.author.equals(bot.user)){
        return;
    }

    if(!message.content.startsWith(PREFIX)){
        return;
    }

    var args = message.content.substring(PREFIX.length).split(" "); //will give us our args in an array
    
    
    switch (args[0].toLowerCase()){
        case "help":
            var embed = new Discord.RichEmbed()
                .setTitle("Help: ")
                .setDescription(
                    "!8ball [question] \n"
                    + "!gameadd [valid game from !gameList] - adds a valid game to your profile \n"
                    + "!gameremove [valid game from !gamelist] - removes a game from your list \n"
                    + "!gamelist - displays a list of games you can add to your profile \n"
                    + "-- under construction -- \n"
                    + "!choose 1, 2, 3, ... n - randomly chooses an option from n options \n"
                    + "!slap @[user] \n" 
                    + "!tea \n"
                    + "!joined @[user] - see when [user] joined the server \n"
                    + "!setBirthday [mm/dd] \n")
                .setColor(0xf5df55);
            message.channel.sendEmbed(embed);
            break;
        case "8ball":
            if (args[1]){
                message.channel.sendMessage(fortunes[Math.floor(Math.random() * fortunes.length)]);
            }
            else{
                message.channel.sendMessage("Try '!8ball [question]'");
            }
            break;
        case "gameadd":
            {
                switch (args[1].toLowerCase()){
                    case "overwatch": 
                        gameRole = message.guild.roles.find("name", "Overwatch");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                    break;
                    case "pokemon":
                        gameRole = message.guild.roles.find("name", "Pokemon");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "fortnite":
                        gameRole = message.guild.roles.find("name", "Fortnite");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "pubg":
                        gameRole = message.guild.roles.find("name", "PUBG");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "league":
                    case "league-of-legends":
                        gameRole = message.guild.roles.find("name", "League-of-Legends");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "d&d":
                    case "dnd":
                        gameRole = message.guild.roles.find("name", "D&D");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "party":
                    case "party-game-night":
                        gameRole = message.guild.roles.find("name", "Party-Game-Night");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "minecraft":
                        gameRole = message.guild.roles.find("name", "Minecraft");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "csgo":
                        gameRole = message.guild.roles.find("name", "CSGO");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    case "world":
                    case "world-of-warcraft":
                        gameRole = message.guild.roles.find("name", "World-of-Warcraft");
                        if(message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You already have this game added.");
                        }else{
                            message.member.addRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been added to your list of games!");
                        }
                        break;
                    default:
                        message.channel.sendMessage("Something went wrong, make sure you correctly entered the game from our '!gamelist'.");
                }
            }
            break;
        case "gameremove":
            {
                switch (args[1].toLowerCase()){
                    case "overwatch": 
                        gameRole = message.guild.roles.find("name", "Overwatch");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                    break;

                    case "pokemon":
                        gameRole = message.guild.roles.find("name", "Pokemon");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "fortnite":
                        gameRole = message.guild.roles.find("name", "Fortnite");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "pubg":
                        gameRole = message.guild.roles.find("name", "PUBG");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "league":
                    case "league-of-legends":
                        gameRole = message.guild.roles.find("name", "League-of-Legends");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "d&d":
                    case "dnd":
                        gameRole = message.guild.roles.find("name", "D&D");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "party":
                    case "party-game-night":
                        gameRole = message.guild.roles.find("name", "Party-Game-Night");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "minecraft":
                        gameRole = message.guild.roles.find("name", "Minecraft");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "csgo":
                        gameRole = message.guild.roles.find("name", "CSGO");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    case "world":
                    case "world-of-warcraft":
                        gameRole = message.guild.roles.find("name", "World-of-Warcraft");
                        if(!message.member.roles.has(gameRole.id)){
                            message.channel.sendMessage("You don't have this game added.");
                        }else{
                            message.member.removeRole(gameRole);
                            message.channel.sendMessage(gameRole.name + " has been removed from your list of games!");
                        }
                        break;
                    default:
                        message.channel.sendMessage("Something went wrong, make sure you correctly entered the game from our '!gamelist'.");
                }
            }
            break;
        case "gamelist":
            var embed = new Discord.RichEmbed()
                .setTitle("Games list: ")
                .setDescription(
                    "csgo \n"
                    + "d&d \n"
                    + "fortnite \n"
                    + "league-of-legends \n"
                    + "minecraft \n"
                    + "overwatch \n" 
                    + "party-game-night \n"
                    + "pokemon \n"
                    + "pubg \n"
                    + "pokemon \n"
                    + "world-of-warcraft \n")
                .setColor(0xf5df55);
            message.channel.sendEmbed(embed);
            break;
        default:
            message.channel.sendMessage("Invalid command, please take a look at the !help menu.")
        
    }
});

bot.login('NDE5Mzc0MTQ1ODU2MzQwMDE4.DXvMTA.C2lRy8ENXE3-__nQWqcg31xR9O4');
